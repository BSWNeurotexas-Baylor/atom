// @flow

const f: Function = v => v + 1
module.exports = f

See https://atom.io/releases
